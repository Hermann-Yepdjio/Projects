#setwd("C:\\Users\\YepdjioNkoH\\Downloads\\Winter 2019\\CS 567\\Seminars\\Seminar2\\Seminar2_R_Script")
setwd("/media/hermann/Tonpi/tonpi/Collegecourses/CWU/Graduate School/Winter 2019/CS 567/Seminars/Seminar2/Seminar2")
#install.packages("readxl")
library(readxl)
data = read_excel("data.xlsx", col_names = FALSE) #read the excel file
data = data.frame(c(data$..1, data$..2), c(data$..4, data$..5), c(data$..7, data$..8) ) #combine the 6 columns 2 by 2 into one to make 3 columns
colnames(data) <- c('X', 'Y', 'Z') #assign names to columns
print(data)



#install.packages("ggplot2")
#install.packages("reshape")
library(ggplot2)
#library(reshape)

# install.packages("car")
# install.packages("pastecs")
# install.packages("psych")
# install.packages("Rcmdr")

library(car)
library(pastecs)
#library(psych)
#library(Rcmdr)

#draw histogram and normal curve for dataset1
x11()
myGraph <- ggplot(data, aes(data$X))
myGraph <- myGraph + geom_histogram(aes(y = ..density..)) + labs(title = "1st Table") + stat_function(fun = dnorm, args =
                                                list(mean = mean(data$X, na.rm = TRUE), sd = sd(data$X, na.rm = TRUE)), colour
                                              = "black", size = 1)

print (myGraph)
ggsave(filename = "images/Table_1_histogram.png", plot = myGraph)#saves the histogram into the images folder
#draw qqplot for dataset 1
qqplot.X <- qplot(sample = data$X, stat = "qq" )
qqplot.X
ggsave(filename = "images/Table_1_qqplot.png", plot = qqplot.X) #saves the qqplot into the images folder

#draw histogram for dataset 2
x11()
myGraph <- ggplot(data, aes(data$Y))
myGraph <- myGraph + geom_histogram(aes(y = ..density..)) + labs(title = "2nd Table") + stat_function(fun = dnorm, args =
                                                      list(mean = mean(data$Y, na.rm = TRUE), sd = sd(data$Y, na.rm = TRUE)), colour
                                                        = "black", size = 1)
print (myGraph)
ggsave(filename = "images/Table_2_histogram.png", plot = myGraph) #saves the histogram into the images folder
#draw qqplot for dataset 2
qqplot.Y <- qplot(sample = data$Y, stat = 'qq' )
qqplot.Y
ggsave(filename = "images/Table_2_qqplot.png", plot = qqplot.Y) #saves the qqplot into the images folder


#draw histogram for dataset 3
x11()
myGraph <- ggplot(data, aes(data$Z))
myGraph <- myGraph + geom_histogram(aes(y = ..density..)) + labs(title = "3rd Table") + stat_function(fun = dnorm, args =
                                                  list(mean = mean(data$Z, na.rm = TRUE), sd = sd(data$Z, na.rm = TRUE)), colour
                                                          = "black", size = 1)
print (myGraph)
ggsave(filename = "images/Table_3_histogram.png", plot = myGraph)#saves the histogram into the images folder
#draw qqplot for dataset 3
qqplot.Z <- qplot(sample = data$Z, stat = 'qq' )
qqplot.Z
ggsave(filename = "images/Table_3_qqplot.png", plot = qqplot.Z) #saves the qqplot into the images folder


#Accessing  Skew and Kurtosis
#describe(cbind(data$X,	data$Y,	data$Z))
stat.desc(cbind(data$X,	data$Y,	data$Z),	basic	=	FALSE,	norm	=	TRUE)

#shapiro test
shapiro.test(data$X)
shapiro.test(data$Y)
shapiro.test(data$Z)

#create a new vector that contains only positive elements of table 3 
new_Z = c()
for (num in data$Z)
{
  if (num >= 0)
    new_Z = c(new_Z, num)
}
print(new_Z)
print(data$Z)
shapiro.test(new_Z)

#log transformation on table 1 and table 3
data$Log_X <- log(data$X +1)
data$Log_Z <- log(data$Z +1)
shapiro.test(data$Log_X)
shapiro.test(data$Log_Z)

#square root transformatio
data$sqrt_X <- log(data$X)
data$sqrt_Z <- log(data$Z)
shapiro.test(data$sqrt_X)
shapiro.test(data$sqrt_Z)

#reciprocal transformation
data$rec_X <- 1/(data$X + 1)
data$rec_Z <- 1/(data$Z + 1)
shapiro.test(data$rec_X)
shapiro.test(data$rec_Z)



