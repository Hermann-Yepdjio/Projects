#include <iostream>
#include "game.h"
#include "players.h"
#include <ctime>

	class Player;
	Game::Game(Player &p1, Player &p2) //constructor
	{
		srand(time(NULL)); // to give rand() a new seed or new starting point to make sure it does not always return the same value
						   ////copied here and not in AiPlayer implementation because it must be called only once to prevent getting repeated values
		P1 = &p1;
		P2 = &p2;
		c_player = &p1;
		number_c_player = 1;
		for(int i =0; i<BoardWidth; i++)
		{
			update[i]=0; //fill the update table with 0s
			for(int j=0; j<BoardHeight; j++) //fill the game table with Emptys
				table[j][i]=Empty;
		}                     
	}
	GameState Game::getState() //retuns the state of the game
	{
		
		for(int i = 0; i<BoardHeight; i++) //check if a player lined 4 pieces in one row
		{
			for (int j = 0; j < BoardWidth - 3; j++)
			{
				if (table[i][j] == Player1 && table[i][j + 1] == Player1 && table[i][j + 2] == Player1 && table[i][j + 3] == Player1)
					return P1Won;
				if (table[i][j] == Player2 && table[i][j + 1] == Player2 && table[i][j + 2] == Player2 && table[i][j + 3] == Player2)
					return P2Won;
			}
		}
		for (int j = 0; j<BoardWidth; j++) //check if player lined 4 pieces in one colum
		{
			for (int i = 0; i < BoardHeight - 3; i++)
			{
				if (table[i][j] == Player1 && table[i+1][j] == Player1 && table[i+2][j] == Player1 && table[i+3][j] == Player1)
					return P1Won;
				if (table[i][j] == Player2 && table[i+1][j] == Player2 && table[i+2][j] == Player2 && table[i+3][j] == Player2)
					return P2Won;
			}
		}
		for (int i = 0; i<BoardHeight-3; i++)// check if player line 4 pieces in one the 1st diagonals
		{
			for (int j = 0; j < BoardWidth - 3; j++)
			{
				if (table[i][j] == Player1 && table[i+1][j + 1] == Player1 && table[i+2][j + 2] == Player1 && table[i+3][j + 3] == Player1)
					return P1Won;
				if (table[i][j] == Player2 && table[i+1][j + 1] == Player2 && table[i+2][j + 2] == Player2 && table[i+3][j + 3] == Player2)
					return P2Won;
			}
		}
		for (int i = 0; i<BoardHeight-3; i++) // check if a player lined 4 pieces in one of the 2nd diagonals
		{
			for (int j = 3; j < BoardWidth; j++)
			{
				if (table[i][j] == Player1 && table[i+1][j - 1] == Player1 && table[i+2][j - 2] == Player1 && table[i+3][j - 3] == Player1)
					return P1Won;
				if (table[i][j] == Player2 && table[i+1][j - 1] == Player2 && table[i+2][j - 2] == Player2 && table[i+3][j - 3] == Player2)
					return P2Won;
			}
		}
		bool condition = true;
		for(int i = 0; i<BoardWidth; i++) //check if the board is full (if there is Draw)
		{
			for(int j =0; j<BoardHeight; j++)
			{
				if (table[j][i]==Empty)
					condition = false;
			}
		}
		if (condition == true)
			return Draw;
		if(number_c_player == 1) //check if player1 is the next to play
			return TurnP1;
		else //player2 is the next to play
			return TurnP2; 

		return Draw;


	}
	bool Game::isRunning() //return "true" if the game is still running and "false" if not
	{
		if(getState() == Draw || getState() == P1Won || getState()== P2Won)
			return false;
		return true;
	}	
	BoardField Game::operator()(int x, int y) const //return the state of the board at the given coordinate
	{
		if (x<0 || x>=BoardWidth || y<0 ||  y>=BoardHeight)
			return Empty;
		return table[y][x];
	}
	void Game::nextTurn()//perform next turn and record changes
	{
		int temp = c_player->getNextTurn(*this);
		if(update[temp-1]<6 && number_c_player == 1)
		{
			table[BoardHeight-1-update[temp-1]][temp-1] = Player1;
			c_player = P2;
			number_c_player = 2;
			update[temp-1]++;  
		}
		else if(update[temp-1]<6 && number_c_player == 2)
		{
			table[BoardHeight-1-update[temp-1]][temp-1] =   Player2;
			c_player=P1;
			number_c_player = 1;
			update[temp-1]++;
		}

		
	}


