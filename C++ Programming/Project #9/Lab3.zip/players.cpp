#include "players.h"
#include "game.h"
#include <iostream>
#include <string>
#include <ctime>
#include <random>
using namespace std;

	class Game;

	//int Player::getNextTurn(Game &game) {}; // pure virtual function because of "=0" which makes the class an abstract class


	int HumanPlayer::getNextTurn(Game &game)  //HumanPlayer class getNextTurn() implementation
	{
		int temp = 0;
		bool condition = false;
		while(!condition) //make sure the user inputs a valid value
		{
			cout<<"Please type an integer between 1 and 7 and press enter: " << endl;
			if (!(cin >> temp))
			{
				cout << "Sorry wrong input type! Please make sure you enter an integer " << endl;
				cin.clear();
				cin.ignore(100, '\n');
			}
			if (temp >= 1 && temp <= 7)
				condition = true;
			else
				cout << "Sorry wrong input! Please make sure the value you enter is between 1 and 7" << endl;
		}
		return temp;
		
	}

	int AiPlayer::getNextTurn(Game &game)  //aiplayer class getnextturn() implementation
	{
		//srand(time(NULL)); // to give rand() a new seed or new starting point to make 
							 //sure it does not always return the same value 
							 //copied in game constructor and not here because it must be called only once to prevent getting repeated values
		int temp = 1 + rand()%7;
		cout<< temp <<"\n";
		return temp;	
	}




