
class Game;
class Player
{
	public:
	Player() = default; //default constructor;
	virtual ~Player() = default ; // virtual destructor;
	virtual int getNextTurn(Game& ) = 0; // pure virtual function because of "=0" which makes the class an abstract class
};

class HumanPlayer: public Player
{
	public:
		HumanPlayer() = default; //default constructor;
		virtual ~HumanPlayer() = default ; // virtual destructor;
		virtual int getNextTurn(Game& ) override;
};
class AiPlayer: public Player
{
	public:
		AiPlayer() = default; //default constructor;
		virtual ~AiPlayer() = default ; // virtual destructor;
		virtual int getNextTurn(Game& ) override ;
};