#include <iostream>
#include <chrono>

using namespace std;
using namespace std::chrono;

int n = 0;
int k = 0;

bool print = false;

void permute(int dep = 0)
{
    static bool* used = new bool[n];
    static int* perm = new int[k];
    
    if (dep == 0)
    {
        for (int i = 0; i < n; i++)
        {
            used[i] = false;
        }
    }
    
    if (dep >= k && print)
    {
        for (int i = 0; i < k; i++)
        {
            cout << perm[i];
        }
        cout << " ";
        return;
    }
    
    for (int i = 0; i < n; i++)
    {
        if (!used[i])
        {
            used[i] = true;
            perm[dep] = i;
            permute(dep + 1);
            used[i] = false;
        }
    }
    
    if (dep == 0)
    {
        delete[] perm;
        delete[] used;
    }
}

inline void swap(int &a, int &b)
{
    int tmp = a;
    a = b;
    b = tmp;
}

void permuteSwap(int dep = 0)
{
    static int* perm = new int[n];
    
    if (dep == 0)
    {
        for (int i = 0; i < n; i++)
        {
            perm[i] = i;
        }
    }
    
    if (dep >= k && print)
    {
        for (int i = 0; i < k; i++)
        {
            cout << perm[i];
        }
        cout << " ";
        return;
    }
    
    for (int i = dep; i < n; i++)
    {
        swap(perm[i], perm[dep]);
        permuteSwap(dep + 1);
        swap(perm[i], perm[dep]);
    }
    
    if (dep == 0)
    {
        delete[] perm;
    }
}


/*
 *  Algorithm taken from 'The Art of Computer Programming', Section 7.2.1.2, Algorithm P (Plain changes)
 */
void PlainChangesPerm(int* perm, int length)
{
    int n = length;

    // Two additional arrays
    int* c = new int[n];
    int* o = new int[n];

    for (int i = 0; i < n; i++)
    {
        c[i] = 0;
        o[i] = 1;
    }

    while (true)
    {

        //-----------------------------------------------------------------
        // current permutation (in perm)

        if (print)
        {
            for (int ii = 0; ii < length; ii++)
            {
                cout << perm[ii];
            }
            cout << " ";
        }

        //-----------------------------------------------------------------

        int j = n - 1;
        int s = 0;
        int tmp;

        while (true)
        {
            int q = c[j] + o[j];

            if (q >= 0)
            {
                if (q != j + 1)
                {

                    tmp = perm[j - c[j] + s];
                    perm[j - c[j] + s] = perm[j - q + s];
                    perm[j - q + s] = tmp;

                    c[j] = q;

                    break;
                }

                if (j == 0)
                    return;

                s++;
            }

            o[j] = -o[j];
            j--;
        }

    }
}

/**
    * Algorithm taken from 'The Art of Computer Programming', Section 7.2.1.3, Algorithm T (Lexicographic combinations)
    */
void knuth(int n, int k)
{
    // Original algorithm:
    // T1. [Initialize.] Set c_j := j - 1 for 1 <= j <= t; then set c_{t+1} := n, c_{t+2} := 0, and j := t.
    // T2. [Visit.] (At this point j is the smallest index such that c_{j+1} > j.) Visit the combination c_t ... c_2c_1. Then, if j > 0, set x := j and go to step T6.
    // T3. [Easy Case?] If c_1 + 1 < c_2, set c_1 := c_1 + 1 and return to T2. Otherwise set j := 2.
    // T4. [Find j.] Set c_{j-1} := j - 2 and x := c_j + 1. If x = c_{j+1}, set j := j + 1 and repeat this step until x != c_j+1.
    // T5. [Done?] Terminate the algorithm if j > t.
    // T6. [Increase c_j.] Set c_j := x, j := j - 1, and return to T2.

    // ---------------------------------------------

    // T1. [Initialize.]
    //     Set c_j := j - 1 for 1 <= j <= t;
    //     then set c_{t+1} := n, c_{t+2} := 0, and j := t.

    int* c = new int[k + 2];

    for (int i = 0; i < k; i++)
        c[i] = i;

    c[k] = n;
    c[k + 1] = 0;

    int j = k;
    int x;

    // ---------------------------------------------

        int* combi = new int[k];

    while (true)
    {
        // T2. [Visit.]
        //     (At this point j is the smallest index such that c_{j+1} > j.)
        //     Visit the combination c_t ... c_2c_1.
        //     Then, if j > 0, set x := j and go to step T6.

        for (int i = 0; i < k; i++)
        {
            combi[i] = c[i];
        }

        // Generate all permutations for this combination.
        PlainChangesPerm(combi, k);

        // Algorithm assumes that n > k. Therefore, we need an extra test.
        // Otherwise the algorithm would not terminate.
        if (n == k){delete[] c;delete[] combi;
            return;}

        if (j > 0)
        {
            x = j;
        }
        else
        {
            // ---------------------------------------------

            // T3. [Easy Case?]
            //     If c_1 + 1 < c_2,
            //         set c_1 := c_1 + 1 and return to T2.
            //     Otherwise
            //         set j := 2.

            if (c[0] + 1 < c[1])
            {
                c[0]++;
                continue;
            }
            else
            {
                j = 2;
            }

            // ---------------------------------------------

            // T4. [Find j.]
            //     Set c_{j-1} := j - 2 and x := c_j + 1.
            //     If x = c_{j+1},
            //         set j := j + 1 and repeat this step until x != c_j+1.

            do
            {
                c[j - 2] = j - 2;
                x = c[j - 1] + 1;

                if (x == c[j])
                    j++;
                else
                    break;

            } while (true);

            // ---------------------------------------------

            // T5. [Done?]
            //     Terminate the algorithm if j > t.

            if (j > k){delete[] c;delete[] combi;
                return;}

        }

        // ---------------------------------------------

        // T6. [Increase c_j.]
        //     Set c_j := x, j := j - 1, and return to T2.

        c[j - 1] = x;
        j--;
        // continue;
    }delete[]c;delete[] combi;
}




void printTime(int duration)
{
    int digits[4];

    digits[0] = duration / 1000;
    digits[1] = (duration / 100) % 10;
    digits[2] = (duration / 10) % 10;
    digits[3] = duration % 10;
    cout << digits[0] << "." << digits[1] << digits[2] << digits[3] << " sec\n";
}

int main(int argc, char* argv[]) {
    ::n = atoi(argv[1]);
    ::k = atoi(argv[2]);
    
    ::print = argc >= 4 && atoi(argv[3]) > 0;
    
    auto start = high_resolution_clock::now();

    permute();
    if (::print) cout << endl;
    
    auto end = high_resolution_clock::now();
    
    auto permTime = duration_cast<milliseconds>(end - start).count();

    
    // ------------------------------------
    
    
    start = high_resolution_clock::now();

    permuteSwap();
    if (::print) cout << endl;
    
    end = high_resolution_clock::now();
    
    auto swapTime = duration_cast<milliseconds>(end - start).count();
    

    
    // ------------------------------------
    
    
    start = high_resolution_clock::now();

    knuth(::n, ::k);
    if (::print) cout << endl;
    
    end = high_resolution_clock::now();
    
    auto knuthTime = duration_cast<milliseconds>(end - start).count();

    
    // ------------------------------------

    
    cout << "Perm: ";
    printTime(permTime);

    cout << "Swap: ";
    printTime(swapTime);
    
    cout << "Knuth: ";
    printTime(knuthTime);

    return 0;
}


