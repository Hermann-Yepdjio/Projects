#include<algorithm>
#include<fstream>
#include<iostream>

using namespace std;

int percentile(int percent, int numbers[], int size);
inline int percentToIndex(int percent, int size);
int quickselect(int index, int numbers[], int start, int end);
inline void swapIfGreaterWithItems(int keys[], int a, int b);

int main()
{
    ifstream dataFile("examples/data3.txt");
    
    // Read first number (stating how many numbers follow)
    long long int size = -1;
    dataFile >> size;
    
    // Create array to store numbers.
    int* numbers = new int[size];
    
    for (int i = 0; i < size && !dataFile.eof(); i++)
    {
        int number;
        dataFile >> number;
        numbers[i] = number;
    }
    
    cout << "25%: " << percentile(25, numbers, size) << endl;
    cout << "50%: " << percentile(50, numbers, size) << endl;
    cout << "75%: " << percentile(75, numbers, size) << endl;
    
    sort(numbers, numbers + size);
    
    ofstream myfile ("dataSorted.txt");
    if (myfile.is_open())
    {
        myfile << size;
        
        for (int i = 0; i < size; i++)
        {
            myfile << " " << numbers[i];
        }
        myfile.close();
    }
    
    return 0;
}

int percentile(int percent, int numbers[], int size)
{
    int index = (size * percent) / 100 - 1;
    
    if ((size * percent) % 100 != 0)
    {
        index++;
    }

    return quickselect(index, numbers, 0, size - 1);
}

inline void swapIfGreaterWithItems(int keys[], int a, int b)
{
    if (keys[a] > keys[b])
    {
        int h = keys[a];
        keys[a] = keys[b];
        keys[b] = h;
    }
}

int quickselect(int index, int numbers[], int start, int end)
{
    int i = start;
    int j = end;

    // pre-sort the low, middle (pivot), and high values in place.
    // this improves performance in the face of already sorted data, or
    // data that is made up of multiple sorted runs appended together.
    int middle = i + ((j - i) >> 1);

    swapIfGreaterWithItems(numbers, i, middle); // swap the low with the mid point
    swapIfGreaterWithItems(numbers, i, j);      // swap the low with the high
    swapIfGreaterWithItems(numbers, middle, j); // swap the middle with the high

    int x = numbers[middle];

    do
    {
        // Invariant:
        // For all k < i, numbers[k] <= x.
        // For all k > j, numbers[k] >= x.

        while (numbers[i] < x) i++;
        while (x < numbers[j]) j--;

        if (i > j) break;
        if (i < j)
        {
            int tmp = numbers[i];
            numbers[i] = numbers[j];
            numbers[j] = tmp;
        }
        i++;
        j--;
    }
    while (i <= j);
    
    // j < i
    
    if (index <= j)
    {
        end = j;
    }
    else if (index >= i)
    {
        start = i;
    }
    else // j < index < i
    {
        return x;
    }
    
    return quickselect(index, numbers, start, end);
}

