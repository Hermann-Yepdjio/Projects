struct Position
{
	int indexInTable = -1; //position in the table.
	int indexInBin = -1; // position in the linked list.
};
