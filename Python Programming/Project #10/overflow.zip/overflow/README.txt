The file bo2.exe is a Windows executable. Run it from a command prompt.

This program contains an exploitable buffer overflow. 
It is very similar to the example in the text.

