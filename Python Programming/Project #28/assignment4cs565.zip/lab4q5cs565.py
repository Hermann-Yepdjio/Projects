import pygraphviz as pgv
import pandas as pan
import json
import numpy as np
import matplotlib.pyplot as plt
import networkx as nx
import scipy.sparse as sp
import scipy.sparse.linalg

with open("tokyo-metro.json") as f:
    
    data = json.load(f)
    
data.keys()
print(data["C"])
g = nx.Graph()
for line in data.values():
    g.add_weighted_edges_from(line["travel_times"])
    g.add_edges_from(line["transfers"])

for n1, n2 in g.edges():
    g[n1][n2]["transfer"] = "weight" not in g[n1][n2]

on_foot = [e for e in g.edges() if g.get_edge_data(*e)["transfer"]]
on_train = [e for e in g.edges() if not g.get_edge_data(*e)["transfer"]]
colors = [data[n[0].upper()]["color"] for n in g.nodes()]

## Visualize the graph
fig, ax = plt.subplots(1,1, figsize=(14,10))
pos = nx.drawing.nx_agraph.graphviz_layout(g,prog="neato")
nx.draw(g, pos, ax=ax, node_size=200, node_color = colors)
nx.draw_networkx_labels(g,pos=pos, ax=ax, font_size = 6)
nx.draw_networkx_edges(g, pos=pos, ax=ax, edgelist=on_train, width=2)
nx.draw_networkx_edges(g, pos=pos, ax=ax, edgelist=on_foot, edge_color="blue")
plt.savefig('tokyometro.png')




def sp_permute(A, perm_r, perm_c):
    M, N = A.shape
    Pr = sp.coo_matrix((np.ones(M), (perm_r, np.arange(N)))).tocsr()
    Pc = sp.coo_matrix((np.ones(M), (np.arange(M), perm_c))).tocsr()
    return Pr.T * A * Pc.T


g.degree()
d_max = max(d for (n, d) in g.degree())
[(n, d) for (n, d) in g.degree() if d == d_max]
p = nx.shortest_path(g, "Y24", "C19")
np.sum([g[p[n]][p[n+1]]["weight"]
    for n in range(len(p)-1) if "weight" in g[p[n]][p[n+1]]])
h = g.copy()
for n1, n2 in h.edges():
    if h[n1][n2]["transfer"]:
        h[n1][n2]["weight"] = 5

p = nx.shortest_path(h, "Y24", "C19")
np.sum([h[p[n]][p[n+1]]["weight"] for n in range(len(p)-1)])
p = nx.shortest_path(h, "Z1", "H16")
np.sum([h[p[n]][p[n+1]]["weight"] for n in range(len(p)-1)])
A = nx.to_scipy_sparse_matrix(g)
perm = sp.csgraph.reverse_cuthill_mckee(A)

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8, 4))
ax1.spy(A, markersize=2)
ax2.spy(sp_permute(A, perm, perm), markersize=2)

plt.savefig('tokyometro1.png')
