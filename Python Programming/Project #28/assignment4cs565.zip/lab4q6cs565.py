import csv
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
plt.style.use('ggplot')
import seaborn as sns
universe = ['IBM', 'MSFT', 'GOOG', 'AAPL', 'AMZN', 'FB', 'NFLX', 'TSLA', 'ORCL', 'SAP']
#universe_csv = ['IBM.csv', 'MSFT.csv', 'GOOG.csv', 'AAPL.csv', 'AMZN.csv', 'FB.csv', 'NFLX.csv', 'TSLA.csv', 'ORCL.', 'SAP']
col_list = ["Date", "Close", "Adj Close"]
IBM = pd.read_csv ('IBM.csv', usecols=col_list)
MSFT = pd.read_csv('MSFT.csv', usecols=col_list)
GOOG = pd.read_csv('GOOG.csv', usecols=col_list)
AAPL = pd.read_csv('AAPL.csv', usecols=col_list)
AMZN = pd.read_csv('AMZN.csv', usecols=col_list)
FB = pd.read_csv('FB.csv', usecols=col_list)
NFLX = pd.read_csv('NFLX.csv', usecols=col_list)
TSLA = pd.read_csv('TSLA.csv', usecols=col_list)
ORCL = pd.read_csv('ORCL.csv', usecols=col_list)
SAP = pd.read_csv('SAP.csv', usecols=col_list)
df = pd.concat([IBM, MSFT, GOOG, AAPL, AMZN, FB, NFLX, TSLA, ORCL, SAP], join='outer', axis=0, keys=universe)

cash = np.array(range(250))
cash[0]=5000000
def MTM(t, )
dlyMTM = 
